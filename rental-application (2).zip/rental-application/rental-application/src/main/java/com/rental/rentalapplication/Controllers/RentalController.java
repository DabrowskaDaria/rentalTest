package com.rental.rentalapplication.Controllers;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.RentalsDays;
import com.rental.rentalapplication.DTO.DeviceDto;
import com.rental.rentalapplication.DTO.RentalDto;
import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Models.Invoice;
import com.rental.rentalapplication.Models.InvoiceType;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Models.RentalStatus;
import com.rental.rentalapplication.Repository.RentalRepository;
import com.rental.rentalapplication.Repository.RentalStatusRepository;

@Controller
public class RentalController {

	@Autowired
	private RentalRepository rentalRepo;
	
	@Autowired
	private RentalStatusRepository rentalStatusRepo;
	
	@GetMapping("/showRentals")
	public String showRentals(Model model) {
		List<Rental> rentals= rentalRepo.findAll();
		model.addAttribute("rentals", rentals);
		return "rental/showRentals";
	}
	
	@PostMapping("/changeStatus/{id}")
	public String changeStatus(@PathVariable("id") Integer id, @ModelAttribute RentalDto rentalDto) {
		Rental rental=rentalRepo.findById(id).get();
		rental.setRentalStatus(rentalDto.getRentalStatus());
		rentalRepo.save(rental);
		return"redirect:/showRentals";
	}
	
	@GetMapping("/changeStatus/{id}")
	public String changeStatusForm(@PathVariable("id") Integer id,Model model) {
		Rental rental=rentalRepo.findById(id).get();
		List<RentalStatus> rentalStatuses=rentalStatusRepo.findAll();
		model.addAttribute("rental", rental);
		model.addAttribute("rentalStatuses", rentalStatuses);
		model.addAttribute("rentalDto", new RentalDto());
		return "rental/changeStatus";
	}
	
	@GetMapping("/currentRentals")
	public String showCurrentRentals(Model model) {
		List<Rental> rentals= rentalRepo.findByUserId(3);
		model.addAttribute("rentals", rentals);
		
		return "rental/currentRentals";
	}
	
	@PostMapping("/cancelRental/{id}")
	public String cancelRental(@PathVariable ("id") Integer id,RedirectAttributes redirectAttributes ) {
		Rental rental=rentalRepo.findById(id).get();
		if(rental.getRentalStatus().getId()==3 || rental.getRentalStatus().getId()==4) {
			RentalStatus rentalStatus=rentalStatusRepo.findById(2).get();
			//Invoice invoice= new Invoice(LocalDate.now(), id, id, , rental);
			rental.setRentalStatus(rentalStatus);
			rentalRepo.save(rental);
			redirectAttributes.addFlashAttribute("info", "Anulowano wypożyczenie");
		}else if(rental.getRentalStatus().getId()==2 || rental.getRentalStatus().getId()==1){
			System.out.println(rental.getRentalStatus().getId());
			redirectAttributes.addFlashAttribute("info", "Nie można anulować");
			
		}
		
		return"redirect:/currentRentals";
	}
	
	@GetMapping("/historyRentals")
	public String showHistoryRentals(Model model) {
		List<Rental> rentals= rentalRepo.findByUserIdAndRentalStatusId(3, 1);
		model.addAttribute("rentals", rentals);
		return "rental/historyRentals";
	}
	
	@GetMapping("/notReturned")
	public String showNotReturnedRentals(Model model) {
		List<Rental> rentals= rentalRepo.findAll();
		List<RentalsDays> notReturnedRentals= new ArrayList<>();
		LocalDate now= LocalDate.now();
		for (Rental rental : rentals) {
			LocalDate endDate= rental.getRentalEndDate();
			if(endDate.isBefore(now)) {
				Long days=ChronoUnit.DAYS.between(endDate, now);
				notReturnedRentals.add(new RentalsDays(rental, days));
				
			}
			
		}
		model.addAttribute("rentals", notReturnedRentals);
		return "rental/notReturnedRentals";
	}
	
	@GetMapping("/extendRental/{id}")
	public String showExtendRentalForm(@PathVariable ("id") Integer id,Model model) {
		Rental rental=rentalRepo.findById(id).get();
		model.addAttribute("rental", rental);
		return"rental/extendRental";
	}
	
	@PostMapping("/extendRental/{id}")
	public String extendRental(@PathVariable ("id") Integer id,@ModelAttribute RentalDto rentalDto) {
		Rental rental=rentalRepo.findById(id).get();
		rental.setRentalEndDate(rentalDto.getRentalEndDate());
		rentalRepo.save(rental);
		return"redirect:/currentRentals";
	}
}
