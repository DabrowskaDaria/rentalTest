package com.rental.rentalapplication.Controllers;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.rental.rentalapplication.Models.Category;
import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Models.DeviceRental;
import com.rental.rentalapplication.Models.ImageDisplay;
import com.rental.rentalapplication.Repository.DeviceRepository;
import com.rental.rentalapplication.Repository.ImageDisplayRepository;
import com.rental.rentalapplication.Services.CategoryManager;
import com.rental.rentalapplication.Services.DeviceManager;

@Controller
public class HomeController {
	
	@Autowired
	private CategoryManager categoryManager;
	
	@Autowired
	private DeviceManager deviceManager;
	
	@Autowired
	private ImageDisplayRepository imageDisplayRepo;
	
	@Autowired
	private DeviceRepository deviceRepo;
	
	@GetMapping({"","/"})
	public String showHomePage(Model model) {
		List<Category> categories=categoryManager.showCategory();
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("categories", categories);
		model.addAttribute("devices", devices);
		return "homePage/home";
	}
	
	@GetMapping("/homePageForUser")
	public String showHomePageForUser(Model model) {
		return "homePage/HomePageForUser";
	}
	
	@GetMapping("/categories/audio")
	public String showCategoryAudio(Model model) {
		
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/audio/audio";
	}
	
	@GetMapping("/categories/camera")
	public String showCategoryCamera(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/camera/camera";
	}
	
	@GetMapping("/categories/headphone")
	public String showCategoryHeadphone(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/headphone/headphone";
	}
	
	@GetMapping("/categories/laptop")
	public String showCategoryLaptop(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/laptop/laptop";
	}
	@GetMapping("/categories/lighting")
	public String showCategoryLighting(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/lighting/lighting";
	}
	
	@GetMapping("/categories/microphone")
	public String showCategoryMicrophone(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/microphone/microphone";
	}
	@GetMapping("/categories/monitor")
	public String showCategoryMonitor(Model model) {
		//List<Device> devices=deviceManager.showDevices();
		//model.addAttribute("devices", devices);
		List<ImageDisplay> monitors=imageDisplayRepo.findAllByCategoryMonitor();
		List<String> names=new ArrayList<String>();
		for (ImageDisplay monitor : monitors) {
			for (Device device : monitor.getDevices()) {
				names.add(device.getName());
				model.addAttribute("category", device.getCategory().getName());
				
			}
		}
		model.addAttribute("names", names);
		model.addAttribute("monitors", monitors);
		return "/homePage/categories/monitor/monitor";
	}
	
	@GetMapping("/categories/projector")
	public String showCategoryprojector(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/projector/projector";
	}
	@GetMapping("/categories/screen")
	public String showCategoryScreen(Model model) {
		List<ImageDisplay> screens=imageDisplayRepo.findAllByCategoryScreen();
		List<String> names=new ArrayList<String>();
		for (ImageDisplay screen : screens) {
			for (Device device : screen.getDevices()) {
					model.addAttribute("category", device.getCategory().getName());
					names.add(device.getName());
					System.out.println(device.getName());
				}
			}
		model.addAttribute("names", names);
		model.addAttribute("screens", screens);
		return "/homePage/categories/screen/screen";
	}
	
	@GetMapping("/categories/tablet")
	public String showCategoryTablet(Model model) {
		List<Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "/homePage/categories/tablet/tablet";
	}
	
	@GetMapping("/categories/tv")
	public String showCategoryTv(Model model) {
		List<ImageDisplay> tvImageDisplays = imageDisplayRepo.findAllByCategoryTv();
		List<String> names=new ArrayList<String>();
		for (ImageDisplay imageDisplay : tvImageDisplays) {
			for (Device device : imageDisplay.getDevices()) {
				names.add(device.getName());
				model.addAttribute("category", device.getCategory().getName());			}
		}
		model.addAttribute("names", names);
		model.addAttribute("tvImageDisplays", tvImageDisplays);
		return "/homePage/categories/tv/tv";
	}
	
	@GetMapping("/showDetails/{id}")
	public String showDetailsDevice(@PathVariable ("id") Integer id,@RequestParam("deviceCategory") String deviceCategory, Model model) {
		//Device device=deviceManager.getDevice(id);
		//Integer count=deviceRepo.countByCategoryNameAndNameAndPriceAndDepositAndImageDisplayScreenSizeAndImageDisplayScreenResolutionAndImageDisplayRefreshRate(device.getCategory().getName(), device.getName(), device.getPrice(), device.getDeposit(), device.getImageDisplay().getScreenSize(),device.getImageDisplay().getScreenResolution(), device.getImageDisplay().getRefreshRate());
		//model.addAttribute("device", device);
		Integer count;
		switch (deviceCategory) {
        case "telewizor":
        	ImageDisplay imageDisplay1 =imageDisplayRepo.findById(id).get();
				for (Device device : imageDisplay1.getDevices()) {
					model.addAttribute("device", device);
					//Integer count=deviceRepo.countByCategoryNameAndNameAndPriceAndDepositAndImageDisplayScreenSizeAndImageDisplayScreenResolutionAndImageDisplayRefreshRate(device.getCategory().getName(), device.getName(), device.getPrice(), device.getDeposit(), device.getImageDisplay().getScreenSize(),device.getImageDisplay().getScreenResolution(), device.getImageDisplay().getRefreshRate());
					//model.addAttribute("count", count);
					System.out.println(device.getName());
				}
			break;
        case "ekran": 
        	
        	ImageDisplay imageDisplay2 =imageDisplayRepo.findById(id).get();
			for(Device device : imageDisplay2.getDevices()) {
				model.addAttribute("device", device);
				//count2=deviceRepo.countByCategoryNameAndNameAndPriceAndDepositAndImageDisplayScreenFormatAndImageDisplayScreenSizeAndImageDisplayActiveSurface(device.getCategory().getName(), device.getName(), device.getPrice(), device.getDeposit(), device.getImageDisplay().getScreenFormat(),device.getImageDisplay().getScreenSize(), device.getImageDisplay().getActiveSurface());
				//model.addAttribute("count", count2);
			}
			break;
        case "monitor":
        	//Integer count;
        	ImageDisplay monitor =imageDisplayRepo.findById(id).get();
        	List<Device> devices=monitor.getDevices();
        	List<Integer> avaliableDevicesIds=new ArrayList<Integer>();
        	Boolean isAvaliable;
			for(Device device : monitor.getDevices()) {
				model.addAttribute("device", device);
				//count=deviceRepo.countByCategoryNameAndNameAndPriceAndDepositAndImageDisplayScreenSizeAndImageDisplayScreenResolutionAndImageDisplayRefreshRate(device.getCategory().getName(), device.getName(), device.getPrice(), device.getDeposit(), device.getImageDisplay().getScreenSize(),device.getImageDisplay().getScreenResolution(), device.getImageDisplay().getRefreshRate());
				isAvaliable=true;
				for(DeviceRental deviceRental : device.getDeviceRental()) {
					if(deviceRental.getRental().getRentalStatus().getName().equals("Wypożyczone") || deviceRental.getRental().getRentalStatus().getName().equals("Nowe") || deviceRental.getRental().getRentalStatus().getName().equals("W trakcie przygotowania") || deviceRental.getRental().getRentalStatus().getName().equals("Gotowe do odbioru")) {
						isAvaliable=false;
						break;}}
					if(!isAvaliable) {
						continue;}
					avaliableDevicesIds.add(device.getId());
					}
				
			
			System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
			for (Integer ids : avaliableDevicesIds) {
				System.out.println(ids);
			}
			count=avaliableDevicesIds.size();
			model.addAttribute("count", count);
			if(count==0 || count==null) {
				model.addAttribute("isAvaliable", "Nie dostępne");
			}else{
				model.addAttribute("isAvaliable", "Dostępne");
			}
			break;
		}
		return "homePage/deviceDetails";
	}	
	
}
