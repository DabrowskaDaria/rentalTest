package com.rental.rentalapplication.email;

import com.rental.rentalapplication.Models.User;

public class ReturnReminderNotification extends EmailMessage {

	public ReturnReminderNotification(User receiver) {
		super(receiver);
		// TODO Auto-generated constructor stub
	}

	@Override
	public String content() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String subject() {
		// TODO Auto-generated method stub
		return null;
	}

}
