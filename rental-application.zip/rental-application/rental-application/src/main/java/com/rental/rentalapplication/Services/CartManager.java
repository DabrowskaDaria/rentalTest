package com.rental.rentalapplication.Services;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import com.rental.rentalapplication.DTO.CartDataDto;
import com.rental.rentalapplication.DTO.CartMetodsDto;
import com.rental.rentalapplication.DTO.CartPersonCompanyDto;
import com.rental.rentalapplication.Models.Camera;
import com.rental.rentalapplication.Models.Cart;
import com.rental.rentalapplication.Models.Company;
import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Models.DeviceCart;
import com.rental.rentalapplication.Models.DeviceRental;
import com.rental.rentalapplication.Models.Invoice;
import com.rental.rentalapplication.Models.InvoiceType;
import com.rental.rentalapplication.Models.Person;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Models.RentalStatus;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.CameraRepository;
import com.rental.rentalapplication.Repository.CartRepository;
import com.rental.rentalapplication.Repository.CompanyRepository;
import com.rental.rentalapplication.Repository.DeviceCartRepository;
import com.rental.rentalapplication.Repository.DeviceRentalRepository;
import com.rental.rentalapplication.Repository.DeviceRepository;
import com.rental.rentalapplication.Repository.InvoiceRepository;
import com.rental.rentalapplication.Repository.PersonRepository;
import com.rental.rentalapplication.Repository.RentalRepository;
import com.rental.rentalapplication.Repository.UserRepository;
import com.rental.rentalapplication.email.EmailSender;
import com.rental.rentalapplication.email.NewRentalNotification;
import com.rental.rentalapplication.security.SecurityService;

import jakarta.servlet.http.HttpSession;

@Service
public class CartManager {
	
	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private DeviceManager deviceManager;
	
	@Autowired
	private DeviceCartRepository deviceCartRepo;
	
	@Autowired
	private CartRepository cartRepo;

	@Autowired
	private HttpSession httpSession;
	
	@Autowired
	private RentalRepository rentalRepo;
	
	@Autowired
	private DeviceRentalRepository deviceRentalRepo;
	
	@Autowired
	private PersonRepository personRepo;
	
	@Autowired
	private CompanyRepository companyRepo;
	
	@Autowired
	private InvoiceRepository invoiceRepo;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private EmailSender emailSender;
	
	@Autowired
	private CameraRepository cameraRepo;

	
	public void addToCart(@PathVariable Integer id,@RequestParam("numberOfDevices") Integer numberOfDevices,Authentication authentication) {
		List<Integer> avaliableDevicesIds=new ArrayList<Integer>();
		Boolean isAvaliable;
		User user=securityService.getUserFromSession(authentication);
		Cart cart =user.getCart();
		Device device=deviceManager.getDevice(id);
		System.out.println(numberOfDevices);
		/*
		Camera camera=cameraRepo.findById(device.getCamera().getId()).get();
		List<Device> devices=camera.getDevices();
		RentalStatus rentalStatus=new RentalStatus();
		if(device.getCategory().getName()=="kamera") {
			for (Device device2 : devices) {
				isAvaliable=true;
				for(DeviceRental deviceRental : device.getDeviceRental()) {
					deviceRental.getRental().getRentalStatus().getName();
					if(rentalStatus.getName()=="Wypożyczone" || rentalStatus.getName()!="Nowe" || rentalStatus.getName()=="W trakcie przygotowania" || rentalStatus.getName()!="Gotowe do odbioru") {
						isAvaliable=false;
						break;
					}
				}
				if(!isAvaliable) {
					continue;
				}
				avaliableDevicesIds.add(device2.getId());
			}
			
		}
		*/
		//DeviceCart deviceCart= new DeviceCart(cart, device);
		//cart.addDeviceCart(deviceCart);
		//deviceCartRepo.save(deviceCart);
		//cartRepo.save(cart);
	}
	
	public void deleteDeviceFromCart(@PathVariable("id") Integer id) {
		DeviceCart deviceCart=deviceCartRepo.findById(id).get();
		deviceCartRepo.delete(deviceCart);
	}
	
	public void addToDBFirstStep(@ModelAttribute CartDataDto cartDataDto,Authentication authentication) {
		RentalStatus rentalStatus= new RentalStatus();
		rentalStatus.setId(4);
		User user= securityService.getUserFromSession(authentication);
		Rental rental= new Rental(cartDataDto.getRentalStartDate(),cartDataDto.getRentalEndDate(),rentalStatus,user);
		rentalRepo.save(rental);
		for (DeviceCart deviceCart : user.getCart().getDeviceCart()) {
			deviceRentalRepo.save(new DeviceRental(rental, deviceCart.getDevice()));
		}
		httpSession.setAttribute("rentalID", rental.getId());
	}
	
	public void addToDbSecondStep(@ModelAttribute CartMetodsDto cartMetodsDto) {
		Integer rentalIdFromSession = (Integer) httpSession.getAttribute("rentalID");
		System.out.println(rentalIdFromSession);
		Rental rental= rentalRepo.findById(rentalIdFromSession).get();
		rental.setMethodOfReception(cartMetodsDto.getMethodsOfReception());
		rental.setMethodOfPayment(cartMetodsDto.getMethodsOfPayment());
		rentalRepo.save(rental);
	}
	
	public void addToDbFourthStep(@ModelAttribute CartPersonCompanyDto cartPersonCompanyDto,Authentication authentication) {
		if(cartPersonCompanyDto.getPeselNumber()!=null) {
			Person person=personRepo.findById(securityService.getUserFromSession(authentication).getPerson().getId()).get();
			person.setFirstName(cartPersonCompanyDto.getFirstName());
			person.setSurname(cartPersonCompanyDto.getSurname());
			person.setPesel(cartPersonCompanyDto.getPeselNumber());
			person.setPhoneNumber(cartPersonCompanyDto.getPhoneNumber());
			person.setPlace(cartPersonCompanyDto.getPlace());
			person.setHouseNumber(cartPersonCompanyDto.getHouseNumber());
			person.setStreet(cartPersonCompanyDto.getStreet());
			person.setZipCode(cartPersonCompanyDto.getZipCode());
			personRepo.save(person);
		}else {
			Company company=new Company(cartPersonCompanyDto.getName(),cartPersonCompanyDto.getCompanyNumber(),cartPersonCompanyDto.getPlace(),cartPersonCompanyDto.getStreet(),cartPersonCompanyDto.getBuldingNumber(),cartPersonCompanyDto.getZipCode());
			companyRepo.save(company);}
			List<DeviceCart> deviceCart=cartRepo.findById(securityService.getUserFromSession(authentication).getCart().getId()).get().getDeviceCart();
			int totalPrice=0;
			int totalDeposit=0;
			for(DeviceCart dc : deviceCart ) {
				totalPrice+=dc.getDevice().getPrice();
				totalDeposit+=dc.getDevice().getDeposit();
		}
		Integer rentalIdFromSession = (Integer) httpSession.getAttribute("rentalID");
		Rental rental=rentalRepo.findById(rentalIdFromSession).get();
		InvoiceType invoiceType=new InvoiceType();
		invoiceType.setId(2);
		Invoice invoice=new Invoice(LocalDate.now(), totalPrice, totalDeposit, invoiceType, rental);
		invoiceRepo.save(invoice);
		User user=userRepo.findById(securityService.getUserFromSession(authentication).getId()).get();
		NewRentalNotification newRental= new NewRentalNotification (user);
		emailSender.send(newRental);
	}
}
