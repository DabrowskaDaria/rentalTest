package com.rental.rentalapplication.Controllers;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.RentalsDays;

import com.rental.rentalapplication.DTO.RentalDto;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Models.RentalStatus;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.RentalRepository;
import com.rental.rentalapplication.Repository.RentalStatusRepository;
import com.rental.rentalapplication.Repository.UserRepository;
import com.rental.rentalapplication.Services.RentalManager;
import com.rental.rentalapplication.security.SecurityService;

@Controller
public class RentalController {

	@Autowired
	private RentalRepository rentalRepo;
	
	@Autowired
	private RentalStatusRepository rentalStatusRepo;
	
	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private UserRepository userRepo;

	@Autowired
	private RentalManager rentalManager;
	
	@GetMapping("/showRentals")
	public String showRentals(Model model) {
		List<Rental> rentals= rentalRepo.findAll();
		model.addAttribute("rentals", rentals);
		return "rental/showRentals";
	}
	
	@PostMapping("/changeStatus/{id}")
	public String changeStatus(@PathVariable("id") Integer id, @ModelAttribute RentalDto rentalDto) {
		rentalManager.changeRentalStatus(id, rentalDto);
		return"redirect:/showRentals";
	}
	
	@GetMapping("/changeStatus/{id}")
	public String changeStatusForm(@PathVariable("id") Integer id,Model model) {
		Rental rental=rentalRepo.findById(id).get();
		List<RentalStatus> rentalStatuses=rentalStatusRepo.findAll();
		model.addAttribute("rental", rental);
		model.addAttribute("rentalStatuses", rentalStatuses);
		model.addAttribute("rentalDto", new RentalDto());
		return "rental/changeStatus";
	}
	
	@GetMapping("/currentRentals")
	public String showCurrentRentals(Model model,Authentication authentication) {
		User user=userRepo.findById(securityService.getUserFromSession(authentication).getId()).get();
		Integer userID=user.getId();
		List<Rental> rentals= rentalRepo.findByUserId(userID);
		model.addAttribute("rentals", rentals);
		return "rental/currentRentals";
	}
	
	@PostMapping("/cancelRental/{id}")
	public String cancelRental(@PathVariable ("id") Integer id,RedirectAttributes redirectAttributes ) {
		rentalManager.rentalCancel(id, redirectAttributes);
		return"redirect:/currentRentals";
	}
	
	@GetMapping("/historyRentals")
	public String showHistoryRentals(Model model,Authentication authentication) {
		User user=userRepo.findById(securityService.getUserFromSession(authentication).getId()).get();
		Integer userID=user.getId();
		List<Rental> rentals= rentalRepo.findByUserIdAndRentalStatusId(userID, 1);
		model.addAttribute("rentals", rentals);
		return "rental/historyRentals";
	}
	
	@GetMapping("/notReturned")
	public String showNotReturnedRentals(Model model) {
		List<Rental> rentals= rentalRepo.findAll();
		List<RentalsDays> notReturnedRentals= new ArrayList<>();
		LocalDate now= LocalDate.now();
		for (Rental rental : rentals) {
			LocalDate endDate= rental.getRentalEndDate();
			if(endDate.isBefore(now) && rental.getRentalStatus().getId()==6) {
				Long days=ChronoUnit.DAYS.between(endDate, now);
				notReturnedRentals.add(new RentalsDays(rental, days));
			}
		}
		model.addAttribute("rentals", notReturnedRentals);
		return "rental/notReturnedRentals";
	}
	
	@GetMapping("/extendRental/{id}")
	public String showExtendRentalForm(@PathVariable ("id") Integer id,Model model) {
		Rental rental=rentalRepo.findById(id).get();
		model.addAttribute("rental", rental);
		return"rental/extendRental";
	}
	
	@PostMapping("/extendRental/{id}")
	public String extendRental(@PathVariable ("id") Integer id,@ModelAttribute RentalDto rentalDto, RedirectAttributes redirectAttributes) {
		rentalManager.rentalExtend(id, rentalDto, redirectAttributes);
		return"redirect:/currentRentals";
	}
}
