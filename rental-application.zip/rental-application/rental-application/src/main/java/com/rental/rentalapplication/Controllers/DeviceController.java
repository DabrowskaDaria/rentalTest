package com.rental.rentalapplication.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.DTO.DeviceDto;
import com.rental.rentalapplication.Models.AudioDevice;
import com.rental.rentalapplication.Models.Camera;
import com.rental.rentalapplication.Models.Category;
import com.rental.rentalapplication.Models.Computer;
import com.rental.rentalapplication.Models.Connector;
import com.rental.rentalapplication.Models.Device;
import com.rental.rentalapplication.Models.ImageDisplay;
import com.rental.rentalapplication.Models.Lighting;
import com.rental.rentalapplication.Repository.AudioDeviceRepository;
import com.rental.rentalapplication.Repository.CameraRepository;
import com.rental.rentalapplication.Repository.ComputerRepository;
import com.rental.rentalapplication.Repository.DeviceRepository;
import com.rental.rentalapplication.Repository.ImageDisplayRepository;
import com.rental.rentalapplication.Repository.LightingRepository;
import com.rental.rentalapplication.Services.CategoryManager;
import com.rental.rentalapplication.Services.ConnectorManager;
import com.rental.rentalapplication.Services.DeviceManager;

@Controller
@RequestMapping("/device")
public class DeviceController {
	@Autowired
	private DeviceManager deviceManager;
	
	@Autowired
	private CategoryManager categoryManager;
	
	@Autowired
	private ConnectorManager connectorManager;
	
	@Autowired
	private DeviceRepository deviceRepo;
	
	@Autowired
	private ImageDisplayRepository imageDisplayRepo;
	
	@Autowired
	private ComputerRepository computerRepo;
	
	@Autowired
	private LightingRepository lightingRepo;
	
	@Autowired
	private CameraRepository cameraRepo;
	
	@Autowired
	private AudioDeviceRepository audioDeviceRepo;

	@GetMapping("/add")
	public String showcreateDevicePage(Model model) {
		List<Category> categories= categoryManager.showCategory();
		List<Connector> connectors=connectorManager.showConnectors();
	
		model.addAttribute("deviceDto", new DeviceDto() );
		model.addAttribute("categories", categories);
		model.addAttribute("connectors", connectors);
		
		return "device/addDevice";
	}
	
	@PostMapping("/add")
	public String addDevice(@ModelAttribute DeviceDto deviceDto,RedirectAttributes redirectAttributes){
		deviceManager.addDevice(deviceDto,redirectAttributes);
		//redirectAttributes.addFlashAttribute("info", "Dodano urządzenie");
		return "redirect:/device/add";
	}
	
	@GetMapping("/showDevices")
	public String showDevices(Model model) {
		List <Device> devices=deviceManager.showDevices();
		model.addAttribute("devices", devices);
		return "device/showDevices";
	}
	
	@PostMapping("/deleteDevice/{id}/delete")
	public String deleteDevice(@PathVariable("id") Integer id) {
		deviceManager.deleteDevice(id);
		return"redirect:/device/showDevices";
	}
	
	@GetMapping("/modify/{id}")
	public String showModifyDeviceForm(@PathVariable ("id") Integer id, Model model) {
		Device device=deviceManager.getDevice(id);
		model.addAttribute("device", device);
		model.addAttribute("deviceDto", new DeviceDto());
		return "device/modifyDevice";
	}
	
	@PostMapping("/modify/{id}")
	public String modifyDevice(@PathVariable Integer id,@ModelAttribute DeviceDto deviceDto ) {
		Device device=deviceRepo.findById(id).get();
		device.setName(deviceDto.getName());
		device.setPrice(deviceDto.getPrice());
		device.setDeposit(deviceDto.getDeposit());
		device.setDescription(deviceDto.getDescription());
		deviceRepo.save(device);
		
		switch(device.getCategory().getName()){
		case "telewizor":
			Integer imageDisplayId=device.getImageDisplay().getId();
			ImageDisplay imageDisplay= imageDisplayRepo.findById(imageDisplayId).get();
			imageDisplay.setScreenSize(deviceDto.getScreenSize());
			imageDisplay.setScreenResolution(deviceDto.getScreenResolution());
			imageDisplay.setRefreshRate(deviceDto.getRefreshRate());
			imageDisplayRepo.save(imageDisplay);
			break;
		case "monitor":
			Integer imageDisplayId1=device.getImageDisplay().getId();
			ImageDisplay imageDisplay1= imageDisplayRepo.findById(imageDisplayId1).get();
			imageDisplay1.setScreenSize(deviceDto.getScreenSize());
			imageDisplay1.setScreenResolution(deviceDto.getScreenResolution());
			imageDisplay1.setRefreshRate(deviceDto.getRefreshRate());
			imageDisplayRepo.save(imageDisplay1);
			break;
		case "ekran":
			Integer imageDisplayId2=device.getImageDisplay().getId();
			ImageDisplay imageDisplay2= imageDisplayRepo.findById(imageDisplayId2).get();
			imageDisplay2.setScreenFormat(deviceDto.getScreenFormat());
			imageDisplay2.setScreenSize(deviceDto.getScreenSize());
			imageDisplay2.setActiveSurface(deviceDto.getActiveSurface());
			imageDisplayRepo.save(imageDisplay2);
			break;
		case "projektor multimedialny":
			Integer imageDisplayId3=device.getImageDisplay().getId();
			ImageDisplay imageDisplay3= imageDisplayRepo.findById(imageDisplayId3).get();
			imageDisplay3.setMatrixType(deviceDto.getMatrixType());
			imageDisplay3.setLampPower(deviceDto.getLampPower());
			imageDisplay3.setScreenResolution(deviceDto.getScreenResolution());
			imageDisplayRepo.save(imageDisplay3);
			break;
		case "laptop":
			Integer computerId=device.getComputer().getId();
			Computer computer= computerRepo.findById(computerId).get();
			computer.setOperatingSystem(deviceDto.getOperatingSystem());
			computer.setDisplay(deviceDto.getDisplay());
			computer.setDrive(deviceDto.getDrive());
			computer.setGraphicsCard(deviceDto.getGraphicsCard());
			computer.setProcessor(deviceDto.getProcessor());
			computer.setRam(deviceDto.getRam());
			computerRepo.save(computer);
			break;
		case "tablet":
			Integer computerId1=device.getComputer().getId();
			Computer computer1= computerRepo.findById(computerId1).get();
			computer1.setOperatingSystem(deviceDto.getOperatingSystem());
			computer1.setDisplay(deviceDto.getDisplay());
			computer1.setDrive(deviceDto.getDrive());
			computer1.setProcessor(deviceDto.getProcessor());
			computer1.setRam(deviceDto.getRam());
			computerRepo.save(computer1);
			break;
		case "oświetlenie":
			Integer lightingId=device.getLighting().getId();
			Lighting lighting= lightingRepo.findById(lightingId).get();
			lighting.setDeviceSize(deviceDto.getDeviceSize());
			lighting.setLampPower(deviceDto.getLampPower());
			lighting.setLightingColor(deviceDto.getLightingColor());
			lighting.setPowerConsumption(deviceDto.getPowerConsumption());
			lightingRepo.save(lighting);
			break;
		case "kamera":
			Integer cameraId=device.getCamera().getId();
			Camera camera= cameraRepo.findById(cameraId).get();
			camera.setImageStabilization(deviceDto.isImageStabilization());
			camera.setOpticalZoom(deviceDto.isOpticalZoom());
			camera.setResolution(deviceDto.getResolution());
			cameraRepo.save(camera);
			break;
		case "nagłośnienie":
			Integer audioDeviceId=device.getAudioDevice().getId();
			AudioDevice audioDevice= audioDeviceRepo.findById(audioDeviceId).get();
			audioDevice.setSpeakersPower(deviceDto.getSpeakersPower());
			audioDevice.setNumberOfspeakers(deviceDto.getNumberOfspeakers());
			audioDeviceRepo.save(audioDevice);
			break;
		case "mikrofon":
			Integer audioDeviceId1=device.getAudioDevice().getId();
			AudioDevice audioDevice1= audioDeviceRepo.findById(audioDeviceId1).get();
			audioDevice1.setMicrophoneType(deviceDto.getMicrophoneType());
			audioDevice1.setFrequencyResponse(deviceDto.getFrequencyResponse());
			audioDevice1.setWirelessTransmission(deviceDto.isWirelessTransmission());
			audioDeviceRepo.save(audioDevice1);
			break;
		case "słuchawki":
			Integer audioDeviceId2=device.getAudioDevice().getId();
			AudioDevice audioDevice2= audioDeviceRepo.findById(audioDeviceId2).get();
			audioDevice2.setHeadphoneType(deviceDto.getHeadphoneType());
			audioDevice2.setMicrophone(deviceDto.isMicrophone());
			audioDevice2.setWirelessTransmission(deviceDto.isWirelessTransmission());
			audioDevice2.setWorkingTime(deviceDto.getWorkingTime());
			audioDeviceRepo.save(audioDevice2);
			break;
		}
		
		return "redirect:/device/showDevices";
	}
	
}
