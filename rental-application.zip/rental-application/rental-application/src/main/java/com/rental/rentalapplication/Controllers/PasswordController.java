package com.rental.rentalapplication.Controllers;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.rental.rentalapplication.DTO.UserPersonDto;

@Controller
public class PasswordController {

	@GetMapping("/changePassword")
	public String changePasswordForm(Model model) {
		model.addAttribute("userPersonDto", new UserPersonDto());
		return "/password/changePassword";
	}
}
