package com.rental.rentalapplication.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.DTO.PasswordDto;
import com.rental.rentalapplication.DTO.UserPersonDto;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.UserRepository;
import com.rental.rentalapplication.email.ChangePasswordEmail;
import com.rental.rentalapplication.email.EmailSender;
import com.rental.rentalapplication.email.NewRentalNotification;
import com.rental.rentalapplication.security.SecurityService;

@Controller
public class PasswordController {

	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private UserRepository userRepo;
		
	@Autowired
	private EmailSender emailSender;
	
	@GetMapping("/changePassword")
	public String changePasswordForm(Model model) {
		model.addAttribute("passwordDto", new PasswordDto());
		return "/password/changePassword";
	}
	
	@PostMapping("/changePassword")
	public String changePassword(Authentication  authentication,PasswordDto passwordDto,RedirectAttributes redirectAttributes) {
		User user=securityService.getUserFromSession(authentication);
		if(passwordDto.getNewPassword().equals(passwordDto.getRepeatedPassword())) {
			BCryptPasswordEncoder passwordEncoder= new BCryptPasswordEncoder();
			user.setPassword(passwordEncoder.encode(passwordDto.getNewPassword()));
			userRepo.save(user);
			ChangePasswordEmail changePasswordEmail=new ChangePasswordEmail(user);
			emailSender.send(changePasswordEmail);
		}else {
			redirectAttributes.addFlashAttribute("info", "Hasła są różne");
		}
		return "redirect:/changePassword";
	}
}
