package com.rental.rentalapplication.DTO;

public class PasswordDto {
	private String password;
}
