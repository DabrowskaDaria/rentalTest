package com.rental.rentalapplication;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.rental.rentalapplication.Models.DeviceCart;
import com.rental.rentalapplication.Models.Rental;
import com.rental.rentalapplication.Repository.CartRepository;

public class RentalCost {
	

	@Autowired
	private CartRepository cartRepo;
	
	private Integer totalPrice=0;
	
	private Integer totalDeposit=0;
	
	public Integer calculateTotalDeposit() {
		List<DeviceCart> deviceCart=cartRepo.findById(1).get().getDeviceCart();
		for(DeviceCart dc : deviceCart ) {
			totalDeposit+=dc.getDevice().getDeposit();
		}
		return totalDeposit;
	}
	
	public Integer calculateTotalPrice() {
		List<DeviceCart> deviceCart=cartRepo.findById(1).get().getDeviceCart();
		
		for(DeviceCart dc : deviceCart ) {
			totalPrice+=dc.getDevice().getPrice();
		}
		return totalPrice;
	}
	
	public Integer calculateCosts(Integer totalPrice, Integer totalDeposit) {
		return totalPrice+totalDeposit;
	}
	
	
}



