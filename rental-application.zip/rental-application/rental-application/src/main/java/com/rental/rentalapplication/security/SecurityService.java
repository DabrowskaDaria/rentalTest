package com.rental.rentalapplication.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.UserRepository;

@Service
public class SecurityService {

	@Autowired
	private UserRepository userRepo;
	
	public User getUserFromSession(Authentication authentication) {
		if(authentication!= null && authentication.getPrincipal() instanceof UserDetails) {
			UserDetails userDetails =(UserDetails) authentication.getPrincipal();
			User user=userRepo.findByEmail(userDetails.getUsername());
			if(user!=null) {
				return user;
			}
		}
	return null;
	}
}
