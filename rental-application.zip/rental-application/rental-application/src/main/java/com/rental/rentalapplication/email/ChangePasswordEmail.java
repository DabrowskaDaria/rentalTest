package com.rental.rentalapplication.email;

import com.rental.rentalapplication.Models.User;

public class ChangePasswordEmail extends EmailMessage {

	public ChangePasswordEmail(User receiver) {
		super(receiver);
	}

	@Override
	public String content() {
		return "Zmieniono hasło";
	}

	@Override
	public String subject() {
		return "Zmiana hasła";
	}

}
