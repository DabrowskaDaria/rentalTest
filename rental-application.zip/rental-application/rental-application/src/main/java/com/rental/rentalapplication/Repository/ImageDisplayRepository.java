package com.rental.rentalapplication.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.rental.rentalapplication.Models.ImageDisplay;

import jakarta.transaction.Transactional;

@Repository
public interface ImageDisplayRepository extends JpaRepository<ImageDisplay, Integer> {
	@Query("SELECT i FROM ImageDisplay i JOIN i.devices d WHERE d.category.name = 'telewizor'")
    List<ImageDisplay> findAllByCategoryTv();
	
	@Query("SELECT i FROM ImageDisplay i JOIN i.devices d WHERE d.category.name = 'monitor'")
    List<ImageDisplay> findAllByCategoryMonitor();
	
	@Query("SELECT i FROM ImageDisplay i JOIN i.devices d WHERE d.category.name = 'ekran'")
    List<ImageDisplay> findAllByCategoryScreen();
	List<ImageDisplay> findByScreenResolutionAndScreenSizeAndRefreshRate(String screenResolution,String screenSize,Integer refreshRate);
	List<ImageDisplay> findByMatrixTypeAndLampPowerAndScreenResolution(String matrixType,Integer lampPower,String screenResolution);
	List<ImageDisplay> findByScreenFormatAndScreenSizeAndActiveSurface(String screenFormat,String screenSize,String activeSurface);
}
