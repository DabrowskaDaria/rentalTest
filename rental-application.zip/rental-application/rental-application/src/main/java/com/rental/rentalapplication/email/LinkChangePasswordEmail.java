package com.rental.rentalapplication.email;

import com.rental.rentalapplication.Models.User;

public class LinkChangePasswordEmail extends EmailMessage {
	
	private  String resetPasswordLink;
	
	public LinkChangePasswordEmail(User receiver,String resetPasswordLink) {
		super(receiver);
		this.resetPasswordLink=resetPasswordLink;
	}

	@Override
	public String content() {
		return "Dzień dobry \n Oto link resetujący hasło: "+resetPasswordLink;
	}

	@Override
	public String subject() {
		return "Link resetujący hasło";
	}

}
