package com.rental.rentalapplication.security;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.util.matcher.AntPathRequestMatcher;

@Configuration
@EnableWebSecurity
public class SecurityConfig {

	
	private UserDetailsService userDetailsService;

	public SecurityConfig(UserDetailsService userDetailsService) {
		super();
		this.userDetailsService = userDetailsService;
	}
	
	@Bean
	public static PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}
	
	@Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            
            .authorizeHttpRequests(authorize -> authorize
            	.requestMatchers("/css/**","/homePage/**","/account/create","/changePassword").permitAll()
            	.requestMatchers("/account/add").hasAuthority("Administrator")
            	.requestMatchers("/showCart","/deleteDeviceFromCart/{id}","/addToCart/{id}").hasAuthority("Użytkownik")
                .anyRequest().authenticated()
            )
            .formLogin(form -> form
            		.loginPage("/login")
            		.usernameParameter("email")
            		.passwordParameter("password")
            		.loginProcessingUrl("/login")
            		.defaultSuccessUrl("/homePage/show")
            		.permitAll()
            		)
            .logout(
            		logout -> logout
            		.logoutUrl("/logout")
            		.logoutSuccessUrl("/homePage/show")
            		.invalidateHttpSession(true)
            		.permitAll()
            		);
            
        return http.build();
    }
	
	
	public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception{
		auth.userDetailsService(userDetailsService).passwordEncoder(passwordEncoder());
	}
	

}
