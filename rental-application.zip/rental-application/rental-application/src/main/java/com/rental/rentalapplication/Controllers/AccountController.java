package com.rental.rentalapplication.Controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.DTO.UserPersonDto;
import com.rental.rentalapplication.Services.AccountManager;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.validation.Valid;

@Controller
@RequestMapping("/account")
public class AccountController {
	
	@Autowired
	private AccountManager accountManager;
	
	@GetMapping("")
	public String showAccountPage(Model model) {
		return "account/account";
	}
	
	@GetMapping("/editAccount")
	public String showEditAccountPage(Model model) {
		return "account/editAccount";
	}
	
	@GetMapping("/create")
	public String showCreateAccountPage(Model model) {
		model.addAttribute("userPersonDto", new UserPersonDto() );
		return "account/createAccount";
	}
	
	@PostMapping("/create")
	public String createAccount(@Valid @ModelAttribute UserPersonDto userPersonDto, BindingResult result,RedirectAttributes redirectAttributes){
		if(result.hasErrors()) {
			return "/account/createAccount";
		}
		accountManager.addAccount(userPersonDto);
		redirectAttributes.addFlashAttribute("info", "Utworzono konto");
		return "redirect:/account/create";
	}
	
	@PostMapping("/delete")
	public String deleteAccount( HttpServletRequest request, HttpServletResponse response,Authentication  authentication) {
		 new SecurityContextLogoutHandler().logout(request, response, authentication);
		 accountManager.deleteAccount(authentication);
		return"redirect:/";
	}
}
