package com.rental.rentalapplication;

import com.rental.rentalapplication.Models.Rental;

public class RentalsDays {
	private Rental rental;
	
	private Long days;

	public RentalsDays(Rental rental, Long days) {
		super();
		this.rental = rental;
		this.days = days;
	}

	public Rental getRental() {
		return rental;
	}

	public void setRental(Rental rental) {
		this.rental = rental;
	}

	public Long getDays() {
		return days;
	}

	public void setDays(Long days) {
		this.days = days;
	}
	
	

	
}
