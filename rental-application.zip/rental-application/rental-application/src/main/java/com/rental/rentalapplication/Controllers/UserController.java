package com.rental.rentalapplication.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.rental.rentalapplication.DTO.UserPersonDto;
import com.rental.rentalapplication.Models.AccountType;
import com.rental.rentalapplication.Models.Person;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.AccountTypeRepository;
import com.rental.rentalapplication.Repository.PersonRepository;
import com.rental.rentalapplication.Repository.UserRepository;
import com.rental.rentalapplication.Services.UserManager;
import com.rental.rentalapplication.security.SecurityService;

import jakarta.validation.Valid;



@Controller
@RequestMapping("/account")
public class UserController {

	@Autowired
	private UserManager userManager;
	
	@Autowired
	AccountTypeRepository accountTypeRepo;
	
	@Autowired
	private SecurityService securityService;
	
	@Autowired
	private UserRepository userRepo;
	
	@Autowired
	private PersonRepository personRepo;
	
	@GetMapping("/create")
	public String showCreateAccountPage(Model model) {
		model.addAttribute("userPersonDto", new UserPersonDto() );
		return "account/createAccount";
	}
	
	@PostMapping("/create")
	public String createAccount(@Valid @ModelAttribute UserPersonDto userPersonDto, BindingResult result,RedirectAttributes redirectAttributes){
		if(result.hasErrors()) {
			return "/account/createAccount";
		}
		userManager.addAccount(userPersonDto);
		redirectAttributes.addFlashAttribute("info", "Utworzono konto");
		return "redirect:/account/create";
	}
	
	
	@GetMapping("/add")
	public String showAddUserPage(Model model) {
		UserPersonDto userPersonDto= new UserPersonDto();
		List<AccountType> accountTypes=accountTypeRepo.findAll();
		model.addAttribute("userPersonDto", userPersonDto);
		model.addAttribute("accountTypes", accountTypes);
		return "account/addUser";
	}
	
	@PostMapping("/add")
	public String addUser(@Valid @ModelAttribute UserPersonDto userPersonDto,BindingResult result, @RequestParam("accountType") String accountType,RedirectAttributes redirectAttributes) {
		if(result.hasErrors()) {
			return "/account/addUser";
		}
		userManager.addUser(userPersonDto, accountType);
		redirectAttributes.addFlashAttribute("info", "Dodano użytkownika");
		return "redirect:/account/add";
	}
	

	@GetMapping("/showUsers")
	public String showUsers(Model model) {
		List <User> users=userManager.showUsers();
		model.addAttribute("users", users);
		return "account/showUsers";
	}
	
	@PostMapping("/delete/{id}/delete")
	public String deleteUser(@PathVariable Integer id) {
		
		userManager.deleteUser(id);
		return "redirect:/account/showUsers";
	}
	
	@GetMapping("/edit")
	public String showEditDataForm(Model model, Authentication  authentication){
		User user=securityService.getUserFromSession(authentication);
		model.addAttribute("user", user);
		model.addAttribute("userPersonDto", new UserPersonDto());
		return "/account/editData";
	}
	
	@PostMapping("/edit")
	public String editData(@ModelAttribute UserPersonDto userPersonDto,Authentication  authentication) {
		Person person=securityService.getUserFromSession(authentication).getPerson();
		person.setFirstName(userPersonDto.getFirstName());
		person.setSurname(userPersonDto.getSurname());
		person.setPhoneNumber(userPersonDto.getPhoneNumber());
		personRepo.save(person);

		return"redirect:/account/edit";
	}
	
	
}
