package com.rental.rentalapplication.Controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import com.rental.rentalapplication.DTO.UserPersonDto;
import com.rental.rentalapplication.Models.AccountType;
import com.rental.rentalapplication.Models.User;
import com.rental.rentalapplication.Repository.AccountTypeRepository;
import com.rental.rentalapplication.Services.UserManager;
import com.rental.rentalapplication.security.SecurityService;

import jakarta.validation.Valid;



@Controller
@RequestMapping("/user")
public class UserController {

	@Autowired
	private UserManager userManager;
	
	@Autowired
	AccountTypeRepository accountTypeRepo;
	
	@Autowired
	private SecurityService securityService;

	@GetMapping("/add")
	public String showAddUserPage(Model model) {
		UserPersonDto userPersonDto= new UserPersonDto();
		List<AccountType> accountTypes=accountTypeRepo.findAll();
		model.addAttribute("userPersonDto", userPersonDto);
		model.addAttribute("accountTypes", accountTypes);
		return "user/addUser";
	}
	
	@PostMapping("/add")
	public String addUser(@Valid @ModelAttribute UserPersonDto userPersonDto,BindingResult result, @RequestParam("accountType") String accountType,RedirectAttributes redirectAttributes) {
		if(result.hasErrors()) {
			return "/user/addUser";
		}
		userManager.addUser(userPersonDto, accountType);
		redirectAttributes.addFlashAttribute("info", "Dodano użytkownika");
		return "redirect:/user/add";
	}
	
	@GetMapping("/showUsers")
	public String showUsers(Model model) {
		List <User> users=userManager.showUsers();
		model.addAttribute("users", users);
		return "user/showUsers";
	}
	
	@PostMapping("/delete/{id}")
	public String deleteUser(@PathVariable Integer id) {
		userManager.deleteUser(id);
		return "redirect:/user/showUsers";
	}
	
	@GetMapping("/edit")
	public String showEditDataForm(Model model, Authentication  authentication){
		User user=securityService.getUserFromSession(authentication);
		model.addAttribute("user", user);
		model.addAttribute("userPersonDto", new UserPersonDto());
		return "/user/editData";
	}
	
	@PostMapping("/edit")
	public String editData(@ModelAttribute UserPersonDto userPersonDto,Authentication  authentication) {
		userManager.changeData(userPersonDto, authentication);
		return"redirect:/user/edit";
	}
	
	
}
